function validate() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    console.log("Username:", username);
    console.log("Password:", password);

    if (username == "") {
        alert("Campo username mancante");
        return false;
    }

    if (password == "") {
        alert("Campo password mancante");
        return false;
    }

    console.log("Validazione completata con successo!");

    
    google.accounts.id.prompt();
    return false;
}
