package indoorSports.persistenza.model;

public class Utente{
    String id;
    String nome;
    String cognome;
    String data_di_nascita;
    String username;
    String password;
    String ruolo;
    String telefono;
    byte[] avatar;
    boolean isGoogleUser;




    public Utente(String id, String nome, String cognome, String data_di_nascita, String username, String password, String ruolo, String telefono) {
        this.id = id;
        this.nome = nome;
        this.cognome = cognome;
        this.data_di_nascita = data_di_nascita;
        this.username = username;
        this.password = password;
        this.ruolo = ruolo;
        this.telefono = telefono;
    }

    public Utente(String nome, String cognome, String data_di_nascita, String username, String password) {
        this.nome = nome;
        this.cognome = cognome;
        this.data_di_nascita = data_di_nascita;
        this.username = username;
        this.password = password;
    }

    public Utente() {    }


    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getData_di_nascita() {
        return data_di_nascita;
    }

    public void setData_di_nascita(String data_di_nascita) {
        this.data_di_nascita = data_di_nascita;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRuolo() {
        return ruolo;
    }
    public void setRuolo(String ruolo) {
        this.ruolo = ruolo;
    }

    public boolean isGoogleUser() {
        return isGoogleUser;
    }
    public void setGoogleUser(boolean isGoogleUser) {
        this.isGoogleUser = isGoogleUser;
    }
    public byte[] getAvatar() {
        return avatar;
    }

    public void setAvatar(byte[] avatar) {
        this.avatar = avatar;
    }


    @Override
    public String toString() {
        return "Utente{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", cognome='" + cognome + '\'' +
                ", data_di_nascita='" + data_di_nascita + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", ruolo='" + ruolo + '\'' +
                ", telefono='" + telefono + '\'' +
                '}';
    }
}









//        utente.setAvatar(rs.getBytes("avatar"));
//        String googleId = rs.getString("google_id");
//        if(googleId != null && googleId.length() > 0)
//            utente.setGoogleUser(true);

//        return utente; }

