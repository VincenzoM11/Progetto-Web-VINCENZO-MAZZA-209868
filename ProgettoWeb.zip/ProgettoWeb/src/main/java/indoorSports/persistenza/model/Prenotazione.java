package indoorSports.persistenza.model;

public class Prenotazione {
    private String id_utente;
    private String data;
    private String orario;
    private String tipologia_campetto;
    private String codice_prenotazione;

    public Prenotazione() {}

    public Prenotazione(String codice_prenotazione, String id_utente, String data, String orario, String tipologia_campetto) {
        this.codice_prenotazione = codice_prenotazione;
        this.id_utente = id_utente;
        this.data = data;
        this.orario = orario;
        this.tipologia_campetto = tipologia_campetto;
    }


    public String getCodice_prenotazione() {
        return codice_prenotazione;
    }

    public void setCodice_prenotazione(String codice_prenotazione) {
        this.codice_prenotazione = codice_prenotazione;
    }

    public String getTipologiaCampetto() { return tipologia_campetto; }

    public void setTipologiaCampetto(String tipologia_campetto) { this.tipologia_campetto = tipologia_campetto; }

    public String getId_utente() {
        return id_utente;
    }

    public void setId_utente(String id_utente) {
        this.id_utente = id_utente;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getOrario() {
        return orario;
    }

    public void setOrario(String orario) {
        this.orario = orario;
    }

    @Override
    public String toString() {
        return "Prenotazione{" +
                "codice_prenotazione=" + codice_prenotazione +
                "id_utente=" + id_utente +
                ", tipologia_campetto='" + tipologia_campetto + '\'' +
                ", data='" + data + '\'' +
                ", orario=" + orario +
                '}';
    }
}
