package indoorSports.persistenza.model;

public class Campetto {

    Long id;
    int campo5;
    int campo6;
    int campo7;

    String indirizzo;

    String descrizione ;


    public Campetto(Long id, int campo5, int campo6, int campo7, String indirizzo, String descrizione){
        this.id = id;
        this.campo5 = campo5;
        this.campo6 = campo6;
        this.campo7 = campo7;
        this.indirizzo = indirizzo;
        this.descrizione = descrizione;
    }
    public Campetto() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }
    public int getCampo5() {
        return campo5;
    }
    public void setCampo5(int campo5) {
        this.campo5 = campo5;
    }
    public int getCampo6() {
        return campo6;
    }
    public void setCampo6(int campo6) {
        this.campo6 = campo6;
    }
    public int getCampo7() {
        return campo7;
    }
    public void setCampo7(int campo7) {
        this.campo7 = campo7;
    }

}
