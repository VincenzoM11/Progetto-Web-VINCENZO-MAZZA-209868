package indoorSports.persistenza;

import indoorSports.persistenza.dao.CampettoDao;
import indoorSports.persistenza.dao.PrenotazioneDao;
import indoorSports.persistenza.dao.UtenteDao;
import indoorSports.persistenza.dao.postgres.CampettoDaoPostgres;
import indoorSports.persistenza.dao.postgres.PrenotazioneDaoPostgres;
import indoorSports.persistenza.dao.postgres.UtenteDaoPostgres;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBManager {

    private static DBManager instance = null;

    public static DBManager getInstance() {
        if (instance == null) {
            instance = new DBManager();
        }
        return instance;
    }

    private DBManager() {
    }

    Connection conn = null;

    public Connection getConnection() {
        if (conn == null) {
            try {
                conn = DriverManager.getConnection("jdbc:postgresql://localhost:5433/postgres", "postgres", "Vincenzo1");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return conn;
    }

    public UtenteDao getUtenteDao() {
        return new UtenteDaoPostgres(getConnection());
    }

    public PrenotazioneDao getPrenotazioneDao() {
    	return new PrenotazioneDaoPostgres(getConnection());
    }

    public CampettoDao getCampettoDao() {
        return new CampettoDaoPostgres(getConnection());
    }



}