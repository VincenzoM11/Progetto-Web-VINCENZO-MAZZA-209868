package indoorSports.persistenza.dao;

import indoorSports.persistenza.model.Prenotazione;

import java.util.List;

public interface PrenotazioneDao {

    public List<Prenotazione> findByUsername(String username);

    public boolean save(Prenotazione prenotazione);

    public boolean delete(Prenotazione prenotazione);

	public int getLastReserveCode();

	public boolean checkTimeAvailability(String date, String time);

}