package indoorSports.persistenza.dao.postgres;


import indoorSports.persistenza.dao.UtenteDao;
import indoorSports.persistenza.model.Utente;
import indoorSports.util.PasswordCrypt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class UtenteDaoPostgres implements UtenteDao {

    Connection conn;
    PasswordCrypt p = new PasswordCrypt();

    public UtenteDaoPostgres(Connection connection) {
        this.conn = connection;
    }

    
    public List<Utente> findAll() {
        List<Utente> utenti = new ArrayList<Utente>();
        String query = "select * from utente";
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
                Utente utente = new Utente();
                utente.setId(rs.getString("id"));
                utente.setNome(rs.getString("nome"));
                utente.setCognome(rs.getString("cognome"));
                utente.setData_di_nascita(rs.getString("data_di_nascita"));
                utente.setUsername(rs.getString("username"));
                utente.setPassword(rs.getString("password"));
                utente.setRuolo(rs.getString("ruolo"));

                utente.setTelefono(rs.getString("telefono"));

                utenti.add(utente);
            }
            return utenti;
        } catch (SQLException e) {
            throw new RuntimeException("Errore durante la ricerca", e);
        }
    }


    public boolean NewUtente(Utente utente) {
        String insertStr = "INSERT INTO utente VALUES (DEFAULT,?,?,?,?,?,DEFAULT,DEFAULT)";

        try {
            PreparedStatement st = this.conn.prepareStatement(insertStr);
            st.setString(1, utente.getNome());
            st.setString(2, utente.getCognome());
            st.setString(3, utente.getData_di_nascita());
            st.setString(4, utente.getUsername());
            String passC = utente.getPassword();
            PasswordCrypt var10001 = this.p;
            utente.setPassword(PasswordCrypt.encode(passC));
            st.setString(5, utente.getPassword());
            st.executeUpdate();
            return true;
        } catch (SQLException var5) {
            return false;
        }
    }


    
    public Utente findByPrimaryKey(String id) {
        Utente utente = null;
        String query = "select * from utente where id = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, id);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                utente = new Utente();
                utente.setId(rs.getString("id"));
                utente.setNome(rs.getString("nome"));
                utente.setCognome(rs.getString("cognome"));
                utente.setData_di_nascita(rs.getString("data_di_nascita"));
                utente.setUsername(rs.getString("username"));
                utente.setPassword(rs.getString("password"));
                utente.setRuolo(rs.getString("ruolo"));

                utente.setTelefono(rs.getString("telefono"));

            }
            return utente;
        } catch (SQLException e) {
            throw new RuntimeException("Errore durante la ricerca", e);
        }
    }

    
    public Utente findByUsername(String username) {
        Utente utente = null;
        String query = "select * from utente where username = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, username);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                utente = new Utente();
                utente.setId(rs.getString("id"));
                utente.setNome(rs.getString("nome"));
                utente.setCognome(rs.getString("cognome"));
                utente.setData_di_nascita(rs.getString("data_di_nascita"));
                utente.setUsername(rs.getString("username"));
                utente.setPassword(rs.getString("password"));
                utente.setRuolo(rs.getString("ruolo"));

                utente.setTelefono(rs.getString("telefono"));

            }
            return utente;
        } catch (SQLException e) {
            throw new RuntimeException("Errore durante la ricerca", e);
        }
    }

    
    public boolean delete(Utente utente) {
        String query = "DELETE FROM utente WHERE id = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, utente.getId());
            st.executeUpdate();
        } catch (SQLException e) {
            return  false;
        }return  true;
    }

    @Override
    public boolean cambioPassword (String utente, String password){
        String newPass = p.encode(password);
        String updateStr = "UPDATE utente set password = ? where id = ?";
        PreparedStatement st;
        try {
            st = conn.prepareStatement(updateStr);
            st.setString(1, newPass);
            st.setString(2, utente);
            st.executeUpdate();

        } catch (SQLException e) {
            return  false;
        }return  true;
    }


    
    public boolean aggiornaUtente(Utente utente) {

        String update = "UPDATE utente set telefono = ?"; //, avatar = ?
        PreparedStatement st;
        try {
            st = conn.prepareStatement(update);
            st.setString(1,utente.getTelefono());
            //st.setByte(2,utente.getAvatar());
            st.executeUpdate();
        } catch (SQLException var5) {
            return false;
        }
        return true;
    }

}

