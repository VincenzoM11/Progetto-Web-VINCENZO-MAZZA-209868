package indoorSports.persistenza.dao.postgres;

import indoorSports.persistenza.dao.CampettoDao;
import indoorSports.persistenza.model.Campetto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CampettoDaoPostgres implements CampettoDao {

    Connection conn;
    public CampettoDaoPostgres(Connection connection) {
        this.conn =connection;
    }

    public List<Campetto> findAll() {
        List<Campetto> campetti = new ArrayList<Campetto>();
        String query = "select * from campetto";

        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()){
                Campetto campetto = new Campetto();
                campetto.setId(rs.getLong("id"));
                campetto.setDescrizione(rs.getString("descrizione"));
                campetto.setIndirizzo(rs.getString("indirizzo"));
                campetto.setCampo5(rs.getInt("campo5"));
                campetto.setCampo6(rs.getInt("campo6"));
                campetto.setCampo7(rs.getInt("campo7"));

                campetti.add(campetto);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return campetti;
    }


    public Campetto findByPrimaryKey(long id) {
        Campetto campetto = null;
        String query = "select * from campetto where id = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setLong(1,id);
            ResultSet rs = st.executeQuery();

            if (rs.next()){
                campetto = new Campetto();
                campetto.setId(rs.getLong("id"));
                campetto.setDescrizione(rs.getString("descrizione"));
                campetto.setIndirizzo(rs.getString("indirizzo"));
                campetto.setCampo5(rs.getInt("campo5"));
                campetto.setCampo6(rs.getInt("campo6"));
                campetto.setCampo7(rs.getInt("campo7"));

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return campetto;
    }


    public boolean save(Campetto campetto) {
        String insertStr = "INSERT INTO campetto VALUES (DEFAULT,?,?,?)";
        PreparedStatement st;
        try {
            st = conn.prepareStatement(insertStr);
            st.setString(1, campetto.getDescrizione());
            st.setString(2, campetto.getIndirizzo());
            st.executeUpdate();

        } catch (SQLException e) {
            return  false;
        }return  true;
    }


    public boolean delete(Campetto campetto) {
        String query = "DELETE FROM campetto WHERE id = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setLong(1,campetto.getId());
            st.executeUpdate();
        } catch (SQLException e) {
            return  false;
        }return  true;
    }

}
