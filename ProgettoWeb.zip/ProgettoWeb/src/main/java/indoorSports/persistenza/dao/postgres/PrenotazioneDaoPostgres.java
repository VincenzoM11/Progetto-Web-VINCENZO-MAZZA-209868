package indoorSports.persistenza.dao.postgres;

import indoorSports.persistenza.DBManager;
import indoorSports.persistenza.dao.PrenotazioneDao;
import indoorSports.persistenza.model.Prenotazione;
import indoorSports.persistenza.model.Utente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PrenotazioneDaoPostgres implements PrenotazioneDao {

    Connection conn;

    public PrenotazioneDaoPostgres(Connection connection) {
        this.conn =connection;
    }


    public List<Prenotazione> findByUsername(String username) {
    	String query = "SELECT p.* FROM prenotazione p JOIN utente u ON p.id_utente = u.id WHERE u.username = ?";
        List<Prenotazione> prenotazioni = new ArrayList<>();

        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, username);
            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Prenotazione prenotazione = new Prenotazione();

                prenotazione.setCodice_prenotazione(rs.getString("codice_prenotazione"));

                Utente u = DBManager.getInstance().getUtenteDao().findByUsername(rs.getString("username"));
                prenotazione.setId_utente(u.getUsername());

                prenotazione.setTipologiaCampetto(rs.getString("tipologia_campetto"));
                prenotazione.setData(rs.getString("data"));
                prenotazione.setOrario(rs.getString("orario"));

                prenotazioni.add(prenotazione);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return prenotazioni;
    }


    public boolean save(Prenotazione prenotazione) {
        String insertStr = "INSERT INTO prenotazione VALUES (?,?,?,?,?)";
        PreparedStatement st;
        try {
            st = conn.prepareStatement(insertStr);
            st.setString(1, prenotazione.getCodice_prenotazione());
            st.setString(2, prenotazione.getId_utente());
            st.setString(3, prenotazione.getTipologiaCampetto());
            st.setString(4, prenotazione.getData());
            st.setString(5, prenotazione.getOrario());
            st.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    public boolean delete(Prenotazione prenotazione) {
        String query = "DELETE FROM prenotazione WHERE codice_prenotazione = ?";
        try {
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1, prenotazione.getCodice_prenotazione());
            st.executeUpdate();
        } catch (SQLException e) {
            return  false;
        }return  true;
    }
    
    public int getLastReserveCode() {
        String query = "SELECT MAX(codice_prenotazione) FROM prenotazione";
        try (PreparedStatement st = conn.prepareStatement(query)) {
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public boolean checkTimeAvailability(String date, String time) {
        String query = "SELECT COUNT(*) FROM prenotazione WHERE data = ? AND orario = ?";
        try (PreparedStatement st = conn.prepareStatement(query)) {
            st.setString(1, date);
            st.setString(2, time);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                return count == 0; // Restituisce true se l'orario è disponibile, altrimenti false
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


}