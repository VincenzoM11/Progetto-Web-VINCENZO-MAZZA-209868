package indoorSports.persistenza.dao;

import indoorSports.persistenza.model.Utente;

import java.sql.SQLException;
import java.util.List;

public interface UtenteDao {
    public List<Utente> findAll();

    public Utente findByPrimaryKey(String id) throws SQLException;

    public Utente findByUsername(String username);

    public boolean NewUtente(Utente utente);

    public boolean delete(Utente utente);

    public boolean cambioPassword(String utente, String password);

    public boolean aggiornaUtente(Utente utente);



}