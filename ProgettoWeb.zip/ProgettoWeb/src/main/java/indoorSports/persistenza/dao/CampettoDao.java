package indoorSports.persistenza.dao;

import indoorSports.persistenza.model.Campetto;

import java.util.List;

public interface CampettoDao {

    public List<Campetto> findAll();

    public Campetto findByPrimaryKey(long id);

    public boolean save(Campetto campetto);

    public boolean delete(Campetto campetto);

}
