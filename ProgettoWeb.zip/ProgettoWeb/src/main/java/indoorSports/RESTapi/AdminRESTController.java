package indoorSports.RESTapi;

import indoorSports.persistenza.DBManager;
import indoorSports.persistenza.model.Prenotazione;
import indoorSports.persistenza.model.Utente;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin("http://localhost:4200")
public class AdminRESTController {

    @PostMapping({"/deleteUtente"})
    public boolean deleteUtente(@RequestBody Utente utente) {
        return DBManager.getInstance().getUtenteDao().delete(utente);
    }

    @PostMapping({"/deletePrenotazione"})
    public boolean deletePrenotazione(@RequestBody Prenotazione prenotazione) {
        return DBManager.getInstance().getPrenotazioneDao().delete(prenotazione);
    }

}
