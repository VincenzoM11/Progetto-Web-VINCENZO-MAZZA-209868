package indoorSports.RESTapi;

import indoorSports.persistenza.DBManager;
import indoorSports.persistenza.model.Prenotazione;
import indoorSports.persistenza.model.Utente;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin({"http://localhost:4200"})
public class AuthenticationRESTController {
    public AuthenticationRESTController() {
    }

    @GetMapping({"/checkAuth"})
    public Utente isAuth(HttpServletRequest req, String jsessionid) {
        System.out.println(jsessionid);
        HttpSession session = (HttpSession)req.getServletContext().getAttribute(jsessionid);
        Utente currentUser = (Utente)session.getAttribute("user");
        return session != null ? currentUser : null;
    }

    @GetMapping({"/logout"})
    public boolean logout(String jsessionid, HttpServletRequest req) {
        if (jsessionid != null) {
            HttpSession session = (HttpSession)req.getServletContext().getAttribute(jsessionid);
            if (session == null) {
                return true;
            } else {
                session.removeAttribute("user");
                session.invalidate();
                return true;
            }
        } else {
            return false;
        }
    }
    

}
