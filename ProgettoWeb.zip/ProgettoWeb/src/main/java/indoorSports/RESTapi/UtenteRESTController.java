package indoorSports.RESTapi;

import indoorSports.persistenza.DBManager;
import indoorSports.persistenza.dao.UtenteDao;
import indoorSports.persistenza.model.Prenotazione;
import indoorSports.persistenza.model.Utente;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
@CrossOrigin("http://localhost:4200")
public class UtenteRESTController {

	@GetMapping("/prenotazioneUtente")
	public List<Prenotazione> prenotazioniUtente(@RequestParam String username){
	    List<Prenotazione> prenotazioni = new ArrayList<>();
	    prenotazioni = DBManager.getInstance().getPrenotazioneDao().findByUsername(username);
	    return prenotazioni;
	}
	
	@GetMapping("/getUsername")
	public List<Prenotazione> getUsername(HttpServletRequest req, @RequestParam("jsessionid") String jsessionid) {
	    HttpSession session = req.getSession();
	    if (session != null) {
	        Utente currentUser = (Utente) session.getAttribute("user");
	        if (currentUser != null) {
	            UtenteDao udao = DBManager.getInstance().getUtenteDao();
	            Utente utente = udao.findByUsername(currentUser.getUsername());
	            if (utente != null) {
	                return prenotazioniUtente(utente.getUsername());
	            }
	        }
	    }
	    return null;
	}

    
    @PostMapping({"/aggiornaUtente"})
    public boolean aggiornaUtente(@RequestBody Utente utente) {
        return DBManager.getInstance().getUtenteDao().aggiornaUtente(utente);
    }

    @PostMapping("/cambioPassword")
    public boolean cambioPassword(@RequestBody String data){
        String pattern = "(\\d+)\\s\\/\\s(.+)";
        Pattern regex = Pattern.compile(pattern);
        Matcher matcher = regex.matcher(data);
        if (matcher.find()) {
            String id = String.valueOf(matcher.group(1));
            String pass = matcher.group(2);
            return DBManager.getInstance().getUtenteDao().cambioPassword(id, pass);
        }
        return false;
    }
}
