package indoorSports.RESTapi;

import indoorSports.persistenza.DBManager;
import indoorSports.persistenza.model.Prenotazione;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin("http://localhost:4200")
public class PrenotazioneRESTController {

	@PostMapping("/newReserve")
    public boolean newReserve (@RequestBody Prenotazione prenotazione){
         return DBManager.getInstance().getPrenotazioneDao().save(prenotazione);
    }
	
	@GetMapping("/lastReserveCode")
    public int getLastReserveCode() {
        return DBManager.getInstance().getPrenotazioneDao().getLastReserveCode();
    }
	
	@GetMapping("/checkTimeAvailability")
    public boolean checkTimeAvailability(@RequestParam String date, @RequestParam String time) {
        return DBManager.getInstance().getPrenotazioneDao().checkTimeAvailability(date, time);
    }
}
