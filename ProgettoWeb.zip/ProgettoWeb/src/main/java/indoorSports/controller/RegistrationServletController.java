package indoorSports.controller;

import indoorSports.persistenza.DBManager;
import indoorSports.persistenza.model.Utente;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/doRegister")
public class RegistrationServletController extends HttpServlet  {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String nome = req.getParameter("nome");
        String cognome = req.getParameter("cognome");
        String data = req.getParameter("data");
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        Utente utente = new Utente(nome,cognome,data,username,password);
        DBManager.getInstance().getUtenteDao().NewUtente(utente);
        resp.sendRedirect("/login.html");
    }
}

