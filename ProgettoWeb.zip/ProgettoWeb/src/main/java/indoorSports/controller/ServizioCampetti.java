package indoorSports.controller;

import indoorSports.persistenza.DBManager;
import indoorSports.persistenza.model.Campetto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpServletRequest;

@Controller()
public class ServizioCampetti {

    @GetMapping("/campetti")
    public String campetti(Model model, HttpServletRequest req) {
        String id = req.getParameter("id");
        Campetto campetto = DBManager.getInstance().getCampettoDao().findByPrimaryKey(Long.parseLong(id));

        model.addAttribute("campetto", campetto);
        return "campetto.html";

    }
}
