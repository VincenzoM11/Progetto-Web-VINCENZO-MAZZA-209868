package indoorSports.controller;


import indoorSports.persistenza.DBManager;
import indoorSports.persistenza.dao.UtenteDao;
import indoorSports.persistenza.model.Utente;
import indoorSports.util.PasswordCrypt;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


@WebServlet({"/doLogin"})
public class LoginServletController extends HttpServlet {
    PasswordCrypt p = new PasswordCrypt();

    public LoginServletController() {
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        UtenteDao udao = DBManager.getInstance().getUtenteDao();
        Utente utente = udao.findByUsername(username);
        boolean logged;
        if (utente == null) {
            logged = false;
        } else {
            if (p.matches(password,utente.getPassword())) {
                logged = true;
                HttpSession session = req.getSession();
                session.setAttribute("user", utente);
                session.setAttribute("sessionId", session.getId());
                req.getServletContext().setAttribute(session.getId(), session);


            }else {
                logged = false;
            }
        }
        if (logged) {
            resp.sendRedirect("http://localhost:4200?jsessionid="+req.getSession().getId());
        }else {
            resp.sendRedirect("/register.html");
        }

    }
    
}